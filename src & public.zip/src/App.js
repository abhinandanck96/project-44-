import './App.css';
import Login from './Login1'
import Button21 from './practice';
import Text from './practice1';
import Control from './control'
import Main from './practice3'
import React, { useReducer } from 'react';
import Greet from './practice5';

function App() {
    const [sum, dispatch] = useReducer((state, action) => {
        return state + action;
    }, 0);

    return ( <
        div > { sum }

        <
        button onClick = {
            () => dispatch(1) } >
        Add 1 <
        /button>

        <
        Button21 / >
        <
        Text / >
        <
        Control / >
        <
        Main / >
        <
        Greet name = "eric" / >
        <
        Greet name = "stan" / > { /*<Login/>*/ } <
        /div>
    );
}

export default App;