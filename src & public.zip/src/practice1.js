import React, { useRef } from 'react';
function Text() {
    const count = useRef(0);
    const handle =() => {
        count.current++;
        console.log(`clicked ${count.current} times`);
    }
    console.log('i rendered')
    return <button onClick={handle}>click me</button>

/*const test = useRef(null);
const onButtonClick =() => {
    test.current.focus();
}
return(
<div>
    <input ref={test} type="text"/>
    <button onClick={onButtonClick}>focus</button>
    </div>
    
)*/
}
export default Text