import React, { useState } from "react";
function Button21() {
    const [buttontext,setbutton]=useState(0);
    /*const click=()=>{
         const update=buttontext+1;
         console.log(`click ${update} times`);
         setbutton(update)
    }*/
    console.log("render again")
    return(
        <div > 
        <button onClick={()=>setbutton(buttontext+1)}>
            {buttontext}
        </button>
        </div>
    )
}
export default Button21