import axios from 'axios'

export const toggleTodo = (payload) => ({

});

export const newAction = () => ({
    type: "NEW_LIST"
});
export const setData = (actionType, responseData) => ({
    type: actionType,
    responseData: responseData

})
export const getDataExample = (url: "https://api.sampleapis.com/futurama/chracters", action) => {
    return (dispatch) => {
        axios.get(url)
            .then((response) => {
                dispatch(setData(action, response.data))
            })
            .catch((error) => {
                dispatch(setData(action, error))
            })
    }
}