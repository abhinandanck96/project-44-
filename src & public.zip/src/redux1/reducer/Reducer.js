const reducer= (state = [], action) => {

    switch (action.type) {
    
    case "TOGGLE_TODO": 
    console.log("reducer", action.payload)
    return {
    testingredux: action.payload
    }
     case "NEW_LIST":
    return {
    test1: "testhgjhsdg"
    }
    case "EXAMPLE1":
        return{
            responseData: action.responseData
        }
       
    
    default:
    return state;
}
    };
    
    export default reducer