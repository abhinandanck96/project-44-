
import React, { createContext } from 'react'
import ReactDOM from 'react-dom'
//import Practice4 from './practice4';
const Context = createContext();
function Main (){
   
   return (
      
      <Context.Provider value ={0} >
         <div>
            <Practice4 />
         </div>
      </Context.Provider>
      
   );
}
export default Main
function Practice4 () {
    
   return (
       <Context.Consumer>
{(value) => <div> the answer is{value}</div>}
       </Context.Consumer>
   )}
