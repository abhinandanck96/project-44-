import React ,{useContext,createContext}from'react'
const Context = createContext();


function Practice4 () {
    
    return (
        <Context.Consumer>
{value => <div> the answer is{value}</div>}
        </Context.Consumer>
              
        
    )
}
export default Practice4