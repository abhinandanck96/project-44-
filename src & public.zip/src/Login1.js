import React, { useEffect, useState } from 'react';
import { connect } from 'react-redux';
import { getDataExample } from './redux1/action/Action';
import { Button, Container } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Login1.css';
const ReduxExample = (props) => {
        const [email, setEmail] = useState("");
        let errorsObj = { email: "", password: "" };
        const [errors, setErrors] = useState(errorsObj);
        const [password, setPassword] = useState("");


        function Login(e) {
            e.preventDefault();
            let error = true;
            const errorObj = {...errorsObj };
            if (email === "") {
                errorObj.email = "Email is Required";
                error = false;
            }
            if (password === "") {
                errorObj.password = "Password is required";
                error = false;
            }

            setErrors(errorObj);
            if (error) {
                alert("login successful");
                props.dispatch(
                    getDataExample("https://api.sampleapis.com/futurama/characters", "EXAMPLE1")
                )
            }
        }
        useEffect(() => {
            console.log("login", props.responseData)
        }, [props.responseData])
        return (

                <
                div >
                <
                h2 > Login form < /h2>

                <
                Form onSubmit = { Login }
                className = "label1" >
                <
                Form.Group className = "col-6" >
                <
                Form.Label className = "label" > Enter Email: < /Form.Label> <
                Form.Control className = "label"
                type = "email"
                placeholder = "Enter email address"
                onChange = {
                    (e) => { setEmail(e.target.value) } }
                /> <
                /Form.Group> {
                    errors.email && < div > { errors.email } < /div>} <
                        Form.Group className = "col-6" >
                        <
                        Form.Label className = "label2" > Enter password: < /Form.Label> <
                        Form.Control type = "password"
                    placeholder = "Enter password"
                    onChange = {
                        (e) => { setPassword(e.target.value) } }
                    /> <
                    /Form.Group> {
                        errors.password && < div > { errors.password } < /div>}<br></br >
                            <
                            Button variant = "primary"
                        type = "submit" >
                            Login <
                            /Button> <
                            /Form>

                        <
                        /div>
                    )
                }
                const mapStateToProps = (state) => ({
                    responseData: state.responseData,
                })
                export default connect(mapStateToProps)(ReduxExample)

                /*
/*
}
const mapStateToProps = (state) => ({
    responseData:state.responseData,
})
export default connect(mapStateToProps)(ReduxExample)*/

                /*const ReduxExample = (props) =>{
                console.log("new reduce",props.response2)
                    useEffect(()=>{
                        props.dispatch(getDataExample("https://api.npms.io/v2/search?q=react","EXAMPLE1"))
                    },[])
                useEffect(() => {
                    console.log("reduce",props.responseData)
                },[props.responseData])
                useEffect(() => {
                    console.log("post reduce",props.response3)
                },[props.response3])

                    return (
                        <div>
                            <h3>
                                Todo list
                            </h3>
                            {props.responseData && 
                            <div>
                            {props.responseData.total}
                        </div>
                }
                        
                        
                        </div>
                    )
                }*/