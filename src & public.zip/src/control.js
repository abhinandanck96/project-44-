import react, { useRef } from 'react'
function Control(props)
{
    let inputvalue=useRef();
    return(
        <div>
            <form>
                <input type="text" defaultvalue="bar" ref={inputvalue}/>
            </form>
        </div>
    )
}
export default Control